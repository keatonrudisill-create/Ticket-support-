import discord
from discord.ext import commands

TOKEN = "MTUyODE3MzYxMTk2NDMwMTMxMg.GaTKto.QFNOSx7FOGEMr4YoxTxe_oJyMHPIQWplP0I6gs"

intents = discord.Intents.default()
intents.guilds = True
intents.messages = True

bot = commands.Bot(intents=intents)

class TicketView(discord.ui.View):
    @discord.ui.button(label="🎫 Create Ticket", style=discord.ButtonStyle.green)
    async def create_ticket(self, button, interaction):
        guild = interaction.guild

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True)
        }

        channel = await guild.create_text_channel(
            name=f"ticket-{interaction.user.name}",
            overwrites=overwrites
        )

        await channel.send(f"{interaction.user.mention}, welcome to your ticket!")
        await interaction.response.send_message(
            f"✅ Ticket created: {channel.mention}",
            ephemeral=True
        )

@bot.slash_command(description="Send the ticket panel")
@commands.has_permissions(administrator=True)
async def ticket(ctx):
    embed = discord.Embed(
        title="🎫 Support Tickets",
        description="Click the button below to create a ticket.",
        color=discord.Color.blue()
    )

    await ctx.respond(embed=embed, view=TicketView())

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

bot.run(MTUyODE3MzYxMTk2NDMwMTMxMg.GaTKto.QFNOSx7FOGEMr4YoxTxe_oJyMHPIQWplP0I6gs)